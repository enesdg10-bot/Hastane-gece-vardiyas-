# Gece Vardiyası — Çok oyunculu prototip

## Oyun tasarımı
- Mekân: terk edilmiş hastane, servis katı.
- Hedef: servis anahtarını ve sigortayı bulmak, paneli çalıştırmak, çıkıştan kaçmak.
- Mod 1 — Yapay zekâ canavar: iki oyuncu hayatta kalan olur; sunucu canavarı yönetir.
- Mod 2 — Oyuncu canavar: oda kuran hayatta kalan olur, ikinci katılan oyuncu canavarı kontrol eder.
- Kontroller: mobil yön düğmeleri; koşma, saklanma ve etkileşim.

## Yerel çalıştırma
Node.js 18 veya üzeri kurulu olmalı.

```bash
npm install
npm start
```

Ardından bilgisayarda `http://localhost:3000` açılır. Aynı Wi-Fi ağı için telefonlarda bilgisayarın yerel IP adresi ve `:3000` portu kullanılabilir (güvenlik duvarı izin vermelidir).

## İnternetten oynama
Bu klasörü Node.js uygulaması çalıştırabilen bir barındırma hizmetine yükleyin. `npm install` ve `npm start` komutlarının desteklenmesi, WebSocket/Socket.IO bağlantılarının açık olması gerekir. Uygulamanın HTTPS adresini iki telefonda da açın. Birinci oyuncu oda oluşturur, kodu arkadaşına gönderir; ikinci oyuncu aynı siteyi açıp kodla katılır.

Oda kodları bellek içinde tutulur; sunucu yeniden başlatılırsa odalar silinir. Bu sürüm erken prototiptir: oda yeniden bağlanma, güvenlik sertleştirmesi, ses/animasyon ve ayrıntılı düşman yolu bulma sonraki geliştirme konularıdır.
