const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Gece Vardiyasi" }));

const PORT = process.env.PORT || 3000;
const W = 20, H = 15, TILE = 32;
const MAP = [
"####################",
"#....#.............#",
"#....#..#######....#",
"#....#..#.....#....#",
"#.......#.....#....#",
"###.#####.....####.#",
"#...#..............#",
"#...#..#######.###..#",
"#......#.....#......#",
"#.####.#.....#.####.#",
"#......#...........##",
"#..########.####....#",
"#...........#.......#",
"#...........#.......#",
"####################"
];
const rooms = new Map();

function freshRoom(code, mode, hostId) {
  return {
    code, mode, hostId, status: "lobby", players: {}, inputs: {},
    items: [
      { id: "key", type: "key", x: 430, y: 80, got: false },
      { id: "fuse", type: "fuse", x: 110, y: 360, got: false },
      { id: "panel", type: "panel", x: 525, y: 410, used: false },
      { id: "exit", type: "exit", x: 590, y: 430, used: false }
    ],
    monster: { x: 540, y: 330, r: 12, alert: false },
    startedAt: 0, ended: false, result: null, lastTick: Date.now()
  };
}
function freeCell(x, y, r=7) {
  const blocked = (px, py) => {
    const c = Math.floor(px / TILE), row = Math.floor(py / TILE);
    return row < 0 || c < 0 || row >= H || c >= W || MAP[row][c] === "#";
  };
  return !blocked(x-r,y-r) && !blocked(x+r,y-r) && !blocked(x-r,y+r) && !blocked(x+r,y+r);
}
function move(o, dx, dy) {
  if (freeCell(o.x + dx, o.y)) o.x += dx;
  if (freeCell(o.x, o.y + dy)) o.y += dy;
}
function distance(a,b) { return Math.hypot(a.x-b.x,a.y-b.y); }
function publicState(room) {
  return {
    code: room.code, mode: room.mode, status: room.status, result: room.result,
    players: Object.values(room.players).map(p => ({
      id: p.id, name: p.name, role: p.role, x: p.x, y: p.y, hiding: p.hiding,
      stamina: Math.round(p.stamina), connected: true
    })),
    items: room.items, monster: room.monster,
    objective: objective(room), serverTime: Date.now()
  };
}
function objective(room) {
  if (!room.items.find(i=>i.id==="key").got) return "Servis anahtarını bul.";
  if (!room.items.find(i=>i.id==="fuse").got) return "Sigortayı bul.";
  if (!room.items.find(i=>i.id==="panel").used) return "Sigorta panelini çalıştır.";
  return "Çıkış kapısına ulaş!";
}
function emitRoom(room) { io.to(room.code).emit("state", publicState(room)); }
function cleanName(n) { return String(n || "Oyuncu").trim().slice(0,18) || "Oyuncu"; }
function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do { code = Array.from({length:5},()=>chars[Math.floor(Math.random()*chars.length)]).join(""); } while (rooms.has(code));
  return code;
}
function joinRoom(socket, room, name) {
  if (Object.keys(room.players).length >= 2) return socket.emit("errorMessage", "Bu oda dolu.");
  if (room.status !== "lobby") return socket.emit("errorMessage", "Bu oyun zaten başlamış.");
  const count = Object.keys(room.players).length;
  const role = count === 0 ? "survivor" : (room.mode === "player" ? "monster" : "survivor");
  const spawn = role === "monster" ? {x:540,y:330} : (count===0 ? {x:80,y:80} : {x:80,y:112});
  room.players[socket.id] = {
    id: socket.id, name: cleanName(name), role, x: spawn.x, y: spawn.y,
    r: 9, speed: 105, stamina: 100, hiding: false
  };
  room.inputs[socket.id] = {x:0,y:0,run:false};
  socket.join(room.code);
  socket.data.roomCode = room.code;
  socket.emit("joined", {code:room.code, role, mode:room.mode});
  emitRoom(room);
  if (Object.keys(room.players).length === 2) {
    room.status = "playing"; room.startedAt = Date.now();
    if (room.mode === "player") {
      const monsterPlayer = Object.values(room.players).find(p=>p.role==="monster");
      room.monster = monsterPlayer;
    }
    io.to(room.code).emit("notice", "İkinci oyuncu katıldı. Vardiya başladı.");
    emitRoom(room);
  } else {
    socket.emit("notice", "Oda kuruldu. Arkadaşının aynı oda koduyla katılmasını bekle.");
  }
}
io.on("connection", socket => {
  socket.on("createRoom", ({name, mode}) => {
    const code = makeCode();
    const room = freshRoom(code, mode === "player" ? "player" : "ai", socket.id);
    rooms.set(code, room);
    joinRoom(socket, room, name);
  });
  socket.on("joinRoom", ({name, code}) => {
    const normalized = String(code||"").trim().toUpperCase();
    const room = rooms.get(normalized);
    if (!room) return socket.emit("errorMessage", "Bu oda kodu bulunamadı.");
    joinRoom(socket, room, name);
  });
  socket.on("input", data => {
    const code = socket.data.roomCode, room = rooms.get(code), p = room?.players[socket.id];
    if (!room || room.status !== "playing" || !p) return;
    const x = Math.max(-1, Math.min(1, Number(data?.x)||0));
    const y = Math.max(-1, Math.min(1, Number(data?.y)||0));
    room.inputs[socket.id] = {x,y,run:!!data?.run};
    if (p.role === "survivor") p.hiding = !!data?.hiding;
  });
  socket.on("interact", () => {
    const room = rooms.get(socket.data.roomCode), p = room?.players[socket.id];
    if (!room || room.status !== "playing" || !p || p.role !== "survivor") return;
    let near = null, best = 42;
    for (const item of room.items) {
      if (item.got || item.used) continue;
      const d = distance(p,item);
      if (d < best) { best = d; near = item; }
    }
    if (!near) return socket.emit("notice", "Yakında etkileşime geçilecek bir şey yok.");
    if (near.id === "key") { near.got = true; io.to(room.code).emit("notice", `${p.name} servis anahtarını buldu.`); }
    else if (near.id === "fuse") { near.got = true; io.to(room.code).emit("notice", `${p.name} sigortayı buldu.`); }
    else if (near.id === "panel") {
      if (!room.items.find(i=>i.id==="fuse").got) return socket.emit("notice", "Panelde eksik sigorta var.");
      near.used = true; room.monster.alert = true;
      io.to(room.code).emit("notice", "Elektrik geri geldi. Çıkış kilidi açıldı; canavar uyarıldı.");
    } else if (near.id === "exit") {
      if (!room.items.find(i=>i.id==="key").got) return socket.emit("notice", "Kapı kilitli. Servis anahtarı gerekiyor.");
      if (!room.items.find(i=>i.id==="panel").used) return socket.emit("notice", "Önce sigorta panelini çalıştır.");
      room.status = "ended"; room.result = "survivors";
      io.to(room.code).emit("notice", "Hayatta kalan oyuncular hastaneden kaçtı.");
    }
    emitRoom(room);
  });
  socket.on("leaveRoom", () => disconnectFromRoom(socket));
  socket.on("disconnect", () => disconnectFromRoom(socket));
});
function disconnectFromRoom(socket) {
  const code = socket.data.roomCode, room = rooms.get(code);
  if (!room) return;
  delete room.players[socket.id]; delete room.inputs[socket.id];
  socket.leave(code); delete socket.data.roomCode;
  if (!Object.keys(room.players).length) rooms.delete(code);
  else {
    io.to(code).emit("notice", "Bir oyuncunun bağlantısı kesildi. Oda yeniden başlatılana kadar beklemeniz gerekebilir.");
    if (room.status === "playing") { room.status = "lobby"; room.items = freshRoom(code,room.mode,room.hostId).items; room.result=null; room.ended=false; }
    emitRoom(room);
  }
}
setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    if (room.status !== "playing") continue;
    const dt = Math.min(.05, (now - room.lastTick) / 1000 || .05);
    room.lastTick = now;
    const survivors = Object.values(room.players).filter(p=>p.role==="survivor");
    for (const p of survivors) {
      const input = room.inputs[p.id] || {x:0,y:0,run:false};
      const len = Math.hypot(input.x,input.y) || 1;
      const sprint = input.run && p.stamina > 0 && (input.x||input.y) && !p.hiding;
      const speed = p.speed * (sprint ? 1.62 : 1);
      if (!p.hiding) move(p, input.x/len*speed*dt, input.y/len*speed*dt);
      p.stamina = Math.max(0,Math.min(100,p.stamina + (sprint ? -24 : 13)*dt));
    }
    if (room.mode === "player") {
      const mp = Object.values(room.players).find(p=>p.role==="monster");
      if (mp) {
        const input = room.inputs[mp.id] || {x:0,y:0};
        const len = Math.hypot(input.x,input.y) || 1;
        if (input.x || input.y) move(mp, input.x/len*mp.speed*1.15*dt, input.y/len*mp.speed*1.15*dt);
        room.monster = mp;
      }
    }
    if (room.mode === "ai") {
      const target = survivors.filter(p=>!p.hiding).sort((a,b)=>distance(a,room.monster)-distance(b,room.monster))[0];
      if (target && (room.monster.alert || distance(target,room.monster)<175)) {
        const dx=target.x-room.monster.x,dy=target.y-room.monster.y,len=Math.hypot(dx,dy)||1;
        const speed=room.monster.alert?76:58;
        move(room.monster,dx/len*speed*dt,dy/len*speed*dt);
      }
    } else {
      const mp = Object.values(room.players).find(p=>p.role==="monster");
      if (mp) room.monster = mp;
    }
    for (const p of survivors) {
      if (!p.hiding && distance(p,room.monster)<19) {
        room.status="ended"; room.result="monster"; io.to(room.code).emit("notice", `${p.name} canavar tarafından yakalandı.`); break;
      }
    }
    if (now - (room.lastEmit||0) > 80) { room.lastEmit=now; emitRoom(room); }
  }
}, 50);
server.listen(PORT, () => console.log(`Gece Vardiyasi server running on port ${PORT}`));
